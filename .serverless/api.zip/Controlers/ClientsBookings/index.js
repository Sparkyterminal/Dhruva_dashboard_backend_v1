// const jwt = require('jsonwebtoken');
// const Event = require("../../Modals/ClientsBookings");
// const STATUS = require("../../utils/statusCodes");
// const MESSAGE = require("../../utils/messages");

// const Request = require("../../Modals/Request");
// const { validationResult } = require("express-validator");
// // Create new event with advances
// exports.createEvent = async (req, res) => {
//   try {
//     const { clientName, eventDate, venueLocation, agreedAmount, advances } = req.body;

//     if (!clientName || !eventDate || !venueLocation || !agreedAmount || !advances) {
//       return res.status(400).json({ message: "Required fields missing" });
//     }

//     // Validate advances: Array of { advanceNumber, expectedAmount, optional receivedAmount, receivedDate, remarks, updatedBy }
//     if (!Array.isArray(advances) || advances.length === 0) {
//       return res.status(400).json({ message: "Advances must be a non-empty array" });
//     }

//     // Prepare advances array ensuring defaults
//     const advancesData = advances.map(adv => ({
//       advanceNumber: adv.advanceNumber,
//       expectedAmount: adv.expectedAmount,
//       receivedAmount: adv.receivedAmount || 0,
//       receivedDate: adv.receivedDate ? new Date(adv.receivedDate) : null,
//       remarks: adv.remarks || { accounts: "", owner: "", approver: "" },
//       updatedBy: adv.updatedBy || { accounts: null, owner: null, approver: null },
//       updatedAt: adv.updatedAt || { accounts: null, owner: null, approver: null }
//     }));

//     const event = new Event({
//       clientName,
//       eventDate,
//       venueLocation,
//       agreedAmount,
//       advances: advancesData
//     });

//     await event.save();
//     res.status(201).json({ message: "Event created", event });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// // Update advance details by advanceNumber and role (DEPARTMENT / OWNER / APPROVER)
// exports.updateAdvance = async (req, res) => {
//   try {
//     const { eventId, advanceNumber } = req.params;
//     const {  receivedAmount, remarks, receivedDate, userId } = req.body;
//     const token = req.get('Authorization');
//     let decodedToken = await jwt.decode(token);
//     const role = decodedToken.role
//     // validate role
//     const validRoles = ["DEPARTMENT", "OWNER", "APPROVER"];
//     if (!validRoles.includes(role)) {
//       return res.status(400).json({ message: "Invalid role" });
//     }
//     if (receivedAmount == null && remarks == null && !receivedDate) {
//       return res.status(400).json({ message: "At least one of receivedAmount, remarks or receivedDate required" });
//     }

//     const event = await Event.findById(eventId);
//     if (!event) return res.status(404).json({ message: "Event not found" });

//     const advance = event.advances.find(a => a.advanceNumber === parseInt(advanceNumber));
//     if (!advance) return res.status(404).json({ message: "Advance not found" });

//     // Update fields as provided
//     if (typeof receivedAmount === "number") {
//       advance.receivedAmount = receivedAmount;
//     }
//     if (receivedDate) {
//       advance.receivedDate = new Date(receivedDate);
//     }
//     if (typeof remarks === "string") {
//       advance.remarks[role.toLowerCase()] = remarks;
//       advance.updatedBy[role.toLowerCase()] = userId;  // tracked user id
//       advance.updatedAt[role.toLowerCase()] = new Date();
//     }

//     await event.save();

//     res.status(200).json({ message: "Advance updated", advance });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// // Get event by ID, including advances
// exports.getEvent = async (req, res) => {
//   try {
//     const event = await Event.findById(req.params.eventId);
//     if (!event) return res.status(404).json({ message: "Event not found" });

//     res.status(200).json({ event });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// // Get all events with optional pagination
// exports.getAllEvents = async (req, res) => {
//   try {
//     const page = parseInt(req.query.page) || 1;
//     const limit = parseInt(req.query.limit) || 20;
//     const skip = (page - 1) * limit;

//     const events = await Event.find()
//       .sort({ createdAt: -1 })  // latest events first
//       .skip(skip)
//       .limit(limit);

//     const totalEvents = await Event.countDocuments();

//     res.status(200).json({
//       page,
//       limit,
//       totalEvents,
//       totalPages: Math.ceil(totalEvents / limit),
//       events
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// // Edit event details except receivedAmount in advances
// exports.editEventExceptReceivedAmount = async (req, res) => {
//   try {
//     const { eventId } = req.params;
//     const { clientName, eventDate, venueLocation, agreedAmount, advances } = req.body;

//     // Validate basic fields
//     if (!clientName || !eventDate || !venueLocation || !agreedAmount || !Array.isArray(advances)) {
//       return res.status(400).json({ message: "Required fields missing or advances is not an array" });
//     }

//     const event = await Event.findById(eventId);
//     if (!event) return res.status(404).json({ message: "Event not found" });

//     // Update event base details
//     event.clientName = clientName;
//     event.eventDate = new Date(eventDate);
//     event.venueLocation = venueLocation;
//     event.agreedAmount = agreedAmount;

//     // Update advances without changing receivedAmount
//     event.advances = advances.map((adv) => {
//       // Find existing advance to retain receivedAmount and related fields
//       const existingAdvance = event.advances.find(a => a.advanceNumber === adv.advanceNumber);

//       return {
//         advanceNumber: adv.advanceNumber,
//         expectedAmount: adv.expectedAmount,
//         // Preserve existing receivedAmount, receivedDate, remarks, updatedBy, updatedAt
//         receivedAmount: existingAdvance ? existingAdvance.receivedAmount : 0,
//         receivedDate: existingAdvance ? existingAdvance.receivedDate : null,
//         remarks: existingAdvance ? existingAdvance.remarks : { accounts: "", owner: "", approver: "" },
//         updatedBy: existingAdvance ? existingAdvance.updatedBy : { accounts: null, owner: null, approver: null },
//         updatedAt: existingAdvance ? existingAdvance.updatedAt : { accounts: null, owner: null, approver: null },
//       };
//     });

//     await event.save();

//     res.status(200).json({ message: "Event updated (receivedAmount unchanged)", event });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// };


const jwt = require('jsonwebtoken');
const Event = require("../../Modals/ClientsBookings");
const EventName = require("../../Modals/events");
const EventTypeModel = require("../../Modals/eventTypes");
const Coordinator = require("../../Modals/Coordinators");
const STATUS = require("../../utils/statusCodes");
const MESSAGE = require("../../utils/messages");
const mongoose = require("mongoose");

const findEventTypeByIdentifier = (eventDoc, identifier) => {
  if (!identifier || !eventDoc || !Array.isArray(eventDoc.eventTypes)) return null;
  if (mongoose.Types.ObjectId.isValid(identifier)) {
    return eventDoc.eventTypes.id(identifier);
  }
  return eventDoc.eventTypes.find(et => et.eventType === identifier);
};

// Create new event with event types & advances
exports.createEvent = async (req, res) => {
  try {
    const token = req.get('Authorization');
    if (!token) {
      return res.status(401).json({ message: "Authorization token required" });
    }

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.uid) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const {
      eventId,
      eventTypes,
      clientName,
      brideName,
      groomName,
      contactNumber,
      altContactNumber,
      altContactName,
      meetingDate,
      lead1,
      lead2,
      note,
      eventConfirmation,
      advancePaymentType
    } = req.body;

    if (!eventId || !mongoose.Types.ObjectId.isValid(eventId)) {
      return res.status(400).json({ message: "Valid eventId is required" });
    }

    const eventNameDoc = await EventName.findById(eventId);
    if (!eventNameDoc) {
      return res.status(404).json({ message: "Event not found for given eventId" });
    }

    if (!clientName || typeof clientName !== "string" || !clientName.trim()) {
      return res.status(400).json({ message: "clientName is required" });
    }

    if (!contactNumber || typeof contactNumber !== "string" || !contactNumber.trim()) {
      return res.status(400).json({ message: "contactNumber is required" });
    }

    const eventTypesData = [];

    const hasEventTypes = Array.isArray(eventTypes) && eventTypes.length > 0;

    if (hasEventTypes) {
      for (let index = 0; index < eventTypes.length; index++) {
        const type = eventTypes[index];

        // Resolve or create EventType master for this event (optional)
        let eventTypeDoc = null;
        let eventTypeId = type.eventTypeId || null;

        // Handle null values - if explicitly null, allow it
        if (type.eventTypeId === null || type.eventType === null) {
          eventTypeId = null;
        } else if (eventTypeId) {
          // If eventTypeId is provided and not null, validate and use it
          if (!mongoose.Types.ObjectId.isValid(eventTypeId)) {
            throw new Error(`eventTypes[${index}].eventTypeId must be a valid ID`);
          }
          eventTypeDoc = await EventTypeModel.findById(eventTypeId);
          if (!eventTypeDoc) {
            throw new Error(`eventTypes[${index}].eventTypeId does not reference a valid event type`);
          }
        } else if (type.eventType && typeof type.eventType === "string" && type.eventType.trim()) {
          // Fallback: use name + eventId to find or create the EventType master
          eventTypeDoc = await EventTypeModel.findOne({
            name: type.eventType.trim(),
            event: eventId,
          });
          if (!eventTypeDoc) {
            eventTypeDoc = await EventTypeModel.create({
              name: type.eventType.trim(),
              event: eventId,
            });
          }
          eventTypeId = eventTypeDoc._id;
        }
        // If both are null/undefined, eventTypeId remains null (allowed)

        if (!type.startDate) {
          throw new Error(`eventTypes[${index}].startDate is required`);
        }
        if (!type.endDate) {
          throw new Error(`eventTypes[${index}].endDate is required`);
        }

        // Validate coordinator if provided
        let coordinatorId = null;
        if (type.coordinator) {
          if (!mongoose.Types.ObjectId.isValid(type.coordinator)) {
            throw new Error(`eventTypes[${index}].coordinator must be a valid coordinator ID`);
          }
          const coordinatorExists = await Coordinator.findById(type.coordinator);
          if (!coordinatorExists || coordinatorExists.is_archived) {
            throw new Error(`eventTypes[${index}].coordinator references a coordinator that does not exist`);
          }
          coordinatorId = type.coordinator;
        }

        const advancesArray = Array.isArray(type.advances) ? type.advances : [];

        const advancesData = advancesArray.map((adv, advIndex) => {
          if (adv.expectedAmount == null) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].expectedAmount is required`);
          }
          if (!adv.advanceDate) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].advanceDate is required`);
          }

          const advanceNumber = adv.advanceNumber != null ? adv.advanceNumber : advIndex + 1;

          // Validate modeOfPayment if provided
          if (adv.modeOfPayment && !['cash', 'account'].includes(adv.modeOfPayment.toLowerCase())) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].modeOfPayment must be 'cash' or 'account'`);
          }

          return {
            advanceNumber,
            expectedAmount: adv.expectedAmount,
            advanceDate: new Date(adv.advanceDate),
            status: adv.status || "Pending",
            receivedAmount: adv.receivedAmount || null,
            receivedDate: adv.receivedDate ? new Date(adv.receivedDate) : null,
            givenBy: adv.givenBy || null,
            collectedBy: adv.collectedBy || null,
            modeOfPayment: adv.modeOfPayment ? adv.modeOfPayment.toLowerCase() : null,
            remarks: adv.remarks || "",
            updatedBy: adv.updatedBy || null,
            updatedAt: adv.updatedAt ? new Date(adv.updatedAt) : null
          };
        });

        // Handle amount fields - all 6 fields should be stored
        const agreedAmount = type.agreedAmount != null ? type.agreedAmount : undefined;
        const accountAmount = type.accountAmount != null ? type.accountAmount : 0;
        const accountGst = type.accountGst != null ? type.accountGst : 0;
        const accountAmountWithGst = type.accountAmountWithGst != null ? type.accountAmountWithGst : 0;
        const cashAmount = type.cashAmount != null ? type.cashAmount : 0;
        const totalPayable = type.totalPayable != null ? type.totalPayable : 0;

        eventTypesData.push({
          eventType: eventTypeId,
          startDate: new Date(type.startDate),
          endDate: new Date(type.endDate),
          venueLocation: type.venueLocation || null,
          subVenueLocation: type.subVenueLocation || null,
          coordinator: coordinatorId,
          agreedAmount: agreedAmount,
          accountAmount: accountAmount,
          accountGst: accountGst,
          accountAmountWithGst: accountAmountWithGst,
          cashAmount: cashAmount,
          totalPayable: totalPayable,
          advances: advancesData
        });
      }
    }

    const event = new Event({
      eventName: eventId,
      eventTypes: eventTypesData,
      clientName: clientName.trim(),
      brideName: brideName ? brideName.trim() : undefined,
      groomName: groomName ? groomName.trim() : undefined,
      meetingDate: meetingDate ? new Date(meetingDate) : null,
      lead1: lead1 || null,
      lead2: lead2 || null,
      contactNumber: contactNumber.trim(),
      altContactNumber: altContactNumber ? altContactNumber.trim() : undefined,
      altContactName: altContactName ? altContactName.trim() : undefined,
      note: note ? note.trim() : undefined,
      eventConfirmation: eventConfirmation || undefined,
      advancePaymentType: advancePaymentType || undefined,
      createdBy: decodedToken.uid
    });

    await event.save();
    
    // Populate eventName, eventType, leads, and venue details before returning
    await event.populate('eventName', 'id name');
    await event.populate('eventTypes.eventType', 'id name event');
    await event.populate('eventTypes.venueLocation', 'id name address city state');
    await event.populate('eventTypes.subVenueLocation', 'id name venue');
    await event.populate('eventTypes.coordinator', 'id name contact_number email');
    await event.populate('lead1', 'id name contact_number email');
    await event.populate('lead2', 'id name contact_number email');
    await event.populate('createdBy', 'id first_name last_name');
    
    res.status(201).json({ message: "Event created", event });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message || "Server error" });
  }
};

// Update advance details by advanceNumber and role (DEPARTMENT / OWNER / APPROVER)
exports.updateAdvance = async (req, res) => {
  try {
    const { eventId, advanceNumber } = req.params;
    const { receivedAmount, remarks, receivedDate, userId } = req.body;
    const selectedEventType = req.query.eventType || req.body.eventType;
    const token = req.get('Authorization');
    if (!token) return res.status(401).json({ message: "Authorization token required" });

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.role) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const role = decodedToken.role.toUpperCase();
    const validRoles = ["DEPARTMENT", "OWNER", "APPROVER"];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    if (receivedAmount == null && remarks == null && !receivedDate) {
      return res.status(400).json({ message: "At least one of receivedAmount, remarks or receivedDate required" });
    }

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const eventTypeDoc = selectedEventType
      ? findEventTypeByIdentifier(event, selectedEventType)
      : event.eventTypes.find(et => et.advances.some(a => a.advanceNumber === parseInt(advanceNumber, 10)));

    let advance;
    if (eventTypeDoc) {
      advance = eventTypeDoc.advances.find(a => a.advanceNumber === parseInt(advanceNumber));
      if (!advance) return res.status(404).json({ message: "Advance not found" });
    } else {
      advance = event.advances.find(a => a.advanceNumber === parseInt(advanceNumber));
      if (!advance) {
        return res.status(404).json({ message: "Advance not found on event or event types" });
      }
    }

    if (typeof receivedAmount === "number") {
      advance.receivedAmount = receivedAmount;
    }
    if (receivedDate) {
      advance.receivedDate = new Date(receivedDate);
    }
    if (typeof remarks === "string") {
      advance.remarks = remarks;
    }

    
    // Update givenBy, collectedBy, modeOfPayment if provided
    if (req.body.givenBy !== undefined) {
      advance.givenBy = req.body.givenBy || null;
    }
    if (req.body.collectedBy !== undefined) {
      advance.collectedBy = req.body.collectedBy || null;
    }
    if (req.body.modeOfPayment !== undefined) {
      if (req.body.modeOfPayment && !['cash', 'account'].includes(req.body.modeOfPayment.toLowerCase())) {
        return res.status(400).json({ message: "modeOfPayment must be 'cash' or 'account'" });
      }
      advance.modeOfPayment = req.body.modeOfPayment ? req.body.modeOfPayment.toLowerCase() : null;
    }
    
    // Update tracking fields
    advance.updatedBy = userId || decodedToken.uid || null;
    advance.updatedAt = new Date();

    await event.save();

    // Populate eventName, eventType, leads, and venue details before returning
    await event.populate('eventName', 'id name');
    await event.populate('eventTypes.eventType', 'id name event');
    await event.populate('eventTypes.venueLocation', 'id name address city state');
    await event.populate('eventTypes.subVenueLocation', 'id name venue');
    await event.populate('eventTypes.coordinator', 'id name contact_number email');
    await event.populate('lead1', 'id name contact_number email');
    await event.populate('lead2', 'id name contact_number email');

    res.status(200).json({ message: "Advance updated", event, advance });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Update advance entry for a specific event type
exports.addAdvanceToEventType = async (req, res) => {
  try {
    const { eventId, eventTypeId, advanceNumber } = req.params;
    const { expectedAmount, receivedAmount, receivedDate, advanceDate, remarks, userId } = req.body;
    const token = req.get('Authorization');
    if (!token) return res.status(401).json({ message: "Authorization token required" });

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.role) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const role = decodedToken.role.toUpperCase();
    const validRoles = ["DEPARTMENT", "OWNER", "APPROVER"];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    if (!advanceNumber) {
      return res.status(400).json({ message: "advanceNumber param is required" });
    }

    if (expectedAmount == null && receivedAmount == null && !receivedDate && !advanceDate && !remarks) {
      return res.status(400).json({ message: "At least one field is required to update the advance" });
    }

    const parsedAdvanceNumber = parseInt(advanceNumber, 10);
    if (Number.isNaN(parsedAdvanceNumber)) {
      return res.status(400).json({ message: "advanceNumber must be a number" });
    }

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const eventTypeDoc = findEventTypeByIdentifier(event, eventTypeId);
    if (!eventTypeDoc) {
      return res.status(404).json({ message: "Event type not found" });
    }

    const advance = eventTypeDoc.advances.find(a => a.advanceNumber === parsedAdvanceNumber);
    if (!advance) {
      return res.status(404).json({ message: "Advance not found for this event type" });
    }

    if (expectedAmount != null) {
      advance.expectedAmount = expectedAmount;
    }
    if (typeof receivedAmount === "number") {
      advance.receivedAmount = receivedAmount;
    }
    if (advanceDate) {
      advance.advanceDate = new Date(advanceDate);
    }
    if (receivedDate) {
      advance.receivedDate = new Date(receivedDate);
    }
    if (remarks !== undefined) {
      advance.remarks = typeof remarks === "string" ? remarks : (remarks || "");
    }
    
    // Update givenBy, collectedBy, modeOfPayment if provided
    if (req.body.givenBy !== undefined) {
      advance.givenBy = req.body.givenBy || null;
    }
    if (req.body.collectedBy !== undefined) {
      advance.collectedBy = req.body.collectedBy || null;
    }
    if (req.body.modeOfPayment !== undefined) {
      if (req.body.modeOfPayment && !['cash', 'account'].includes(req.body.modeOfPayment.toLowerCase())) {
        return res.status(400).json({ message: "modeOfPayment must be 'cash' or 'account'" });
      }
      advance.modeOfPayment = req.body.modeOfPayment ? req.body.modeOfPayment.toLowerCase() : null;
    }

    advance.updatedBy = userId || decodedToken.uid || null;
    advance.updatedAt = new Date();

    await event.save();

    // Populate eventName, eventType, leads, and venue details before returning
    await event.populate('eventName', 'id name');
    await event.populate('eventTypes.eventType', 'id name event');
    await event.populate('eventTypes.venueLocation', 'id name address city state');
    await event.populate('eventTypes.subVenueLocation', 'id name venue');
    await event.populate('eventTypes.coordinator', 'id name contact_number email');
    await event.populate('lead1', 'id name contact_number email');
    await event.populate('lead2', 'id name contact_number email');

    return res.status(200).json({
      message: "Advance updated successfully",
      event,
      eventType: eventTypeDoc.eventType,
      advance
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Get event by ID, including advances
exports.getEvent = async (req, res) => {
  try {
    const token = req.get('Authorization');
    if (!token) {
      return res.status(401).json({ message: "Authorization token required" });
    }

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.uid) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const event = await Event.findById(req.params.eventId)
      .populate('eventName', 'id name')
      .populate('eventTypes.eventType', 'id name event')
      .populate('eventTypes.venueLocation', 'id name address city state')
      .populate('eventTypes.subVenueLocation', 'id name venue')
      .populate('eventTypes.coordinator', 'id name contact_number email')
      .populate('lead1', 'id name contact_number email')
      .populate('lead2', 'id name contact_number email')
      .populate('createdBy', 'id first_name last_name');
    
    if (!event) return res.status(404).json({ message: "Event not found" });

    // Check if user has access (owner or ADMIN/OWNER can see all)
    // if (decodedToken.role !== 'ADMIN' && decodedToken.role !== 'OWNER') {
    //   if (event.createdBy && event.createdBy.toString() !== decodedToken.uid) {
    //     return res.status(403).json({ message: "Access denied. You can only view your own events." });
    //   }
    // }

    res.status(200).json({ event });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};


exports.getAllEvents = async (req, res) => {
  try {
    // const token = req.get('Authorization');
    // if (!token) {
    //   return res.status(401).json({ message: "Authorization token required" });
    // }

    // const decodedToken = jwt.decode(token);
    // if (!decodedToken || !decodedToken.uid) {
    //   return res.status(401).json({ message: "Invalid token" });
    // }

    // Currently returns all events (no user-based filtering)
    const query = {};

    const events = await Event.find(query)
      .populate('eventName', 'id name')
      .populate('eventTypes.eventType', 'id name event')
      .populate('eventTypes.venueLocation', 'id name address city state')
      .populate('eventTypes.subVenueLocation', 'id name venue')
      .populate('eventTypes.coordinator', 'id name contact_number email')
      .populate('lead1', 'id name contact_number email')
      .populate('lead2', 'id name contact_number email')
      .populate('createdBy', 'id first_name last_name')
      .sort({ createdAt: -1 });  // latest events first

    const totalEvents = events.length;

    res.status(200).json({
      totalEvents,
      events
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};



exports.getMyEvents = async (req, res) => {      
  try {
    const token = req.get('Authorization');
    if (!token) {
      return res.status(401).json({ message: "Authorization token required" });
    }

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.uid) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const events = await Event.find({ createdBy: decodedToken.uid })
      .populate('eventName', 'id name')
      .populate('eventTypes.eventType', 'id name event')
      .populate('eventTypes.venueLocation', 'id name address city state')
      .populate('eventTypes.subVenueLocation', 'id name venue')
      .populate('eventTypes.coordinator', 'id name contact_number email')
      .populate('lead1', 'id name contact_number email')
      .populate('lead2', 'id name contact_number email')
      .populate('createdBy', 'id first_name last_name')
      .sort({ createdAt: -1 });  // latest events first

    return res.status(STATUS.SUCCESS).json({
      success: true,
      events: events,
      message: "Events fetched successfully"
    });
  } catch (error) {
    console.error(error);
    return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: MESSAGE.internalServerError,
      error: error.message
    });
  }
};




// Edit event details except receivedAmount in advances
exports.editEventExceptReceivedAmount = async (req, res) => {
  try {
    const token = req.get('Authorization');
    if (!token) {
      return res.status(401).json({ message: "Authorization token required" });
    }

    const decodedToken = jwt.decode(token);
    if (!decodedToken || !decodedToken.uid) {
      return res.status(401).json({ message: "Invalid token" });
    }

    const { eventId } = req.params;
    const {
      eventId: newEventId,
      eventTypes,
      clientName,
      brideName,
      groomName,
      contactNumber,
      altContactNumber,
      altContactName,
      lead1,
      lead2,
      note,
      meetingDate,
      eventConfirmation,
      advancePaymentType
    } = req.body;

    if (!clientName || typeof clientName !== "string" || !clientName.trim()) {
      return res.status(400).json({ message: "clientName is required" });
    }

    if (!contactNumber || typeof contactNumber !== "string" || !contactNumber.trim()) {
      return res.status(400).json({ message: "contactNumber is required" });
    }

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    // Check if user has access (owner or ADMIN/OWNER can edit all)
    if (decodedToken.role !== 'ADMIN' && decodedToken.role !== 'OWNER') {
      if (event.createdBy && event.createdBy.toString() !== decodedToken.uid) {
        return res.status(403).json({ message: "Access denied. You can only edit your own events." });
      }
    }

    // Update eventId if provided
    if (newEventId) {
      if (!mongoose.Types.ObjectId.isValid(newEventId)) {
        return res.status(400).json({ message: "Valid eventId is required" });
      }
      const eventNameDoc = await EventName.findById(newEventId);
      if (!eventNameDoc) {
        return res.status(404).json({ message: "Event not found for given eventId" });
      }
      event.eventName = newEventId;
    }

    // Update basic fields
    event.clientName = clientName.trim();
    event.brideName = brideName ? brideName.trim() : undefined;
    event.groomName = groomName ? groomName.trim() : undefined;
    event.contactNumber = contactNumber.trim();
    event.altContactNumber = altContactNumber ? altContactNumber.trim() : undefined;
    event.altContactName = altContactName ? altContactName.trim() : undefined;
    event.lead1 = lead1 !== undefined ? (lead1 || null) : event.lead1;
    event.lead2 = lead2 !== undefined ? (lead2 || null) : event.lead2;
    event.note = note ? note.trim() : undefined;
    event.meetingDate = meetingDate ? new Date(meetingDate) : null;
    if (eventConfirmation !== undefined) {
      event.eventConfirmation = eventConfirmation || undefined;
    }
    if (advancePaymentType !== undefined) {
      event.advancePaymentType = advancePaymentType || undefined;
    }

    // Update eventTypes if provided
    const hasEventTypes = Array.isArray(eventTypes) && eventTypes.length > 0;
    if (hasEventTypes) {
      const eventTypesData = [];
      const currentEventId = newEventId || event.eventName;

      for (let index = 0; index < eventTypes.length; index++) {
        const type = eventTypes[index];

        // Resolve or create EventType master for this event (optional)
        let eventTypeDoc = null;
        let eventTypeId = type.eventTypeId || null;

        // Handle null values - if explicitly null, allow it
        if (type.eventTypeId === null || type.eventType === null) {
          eventTypeId = null;
        } else if (eventTypeId) {
          // If eventTypeId is provided and not null, validate and use it
          if (!mongoose.Types.ObjectId.isValid(eventTypeId)) {
            throw new Error(`eventTypes[${index}].eventTypeId must be a valid ID`);
          }
          eventTypeDoc = await EventTypeModel.findById(eventTypeId);
          if (!eventTypeDoc) {
            throw new Error(`eventTypes[${index}].eventTypeId does not reference a valid event type`);
          }
        } else if (type.eventType && typeof type.eventType === "string" && type.eventType.trim()) {
          // Fallback: use name + eventId to find or create the EventType master
          eventTypeDoc = await EventTypeModel.findOne({
            name: type.eventType.trim(),
            event: currentEventId,
          });
          if (!eventTypeDoc) {
            eventTypeDoc = await EventTypeModel.create({
              name: type.eventType.trim(),
              event: currentEventId,
            });
          }
          eventTypeId = eventTypeDoc._id;
        }
        // If both are null/undefined, eventTypeId remains null (allowed)

        // Find existing eventType to preserve receivedAmount in advances
        const existingType = eventTypeId 
          ? event.eventTypes.find(et => 
              et.eventType && et.eventType.toString() === eventTypeId.toString()
            )
          : null;

        if (!type.startDate) {
          throw new Error(`eventTypes[${index}].startDate is required`);
        }
        if (!type.endDate) {
          throw new Error(`eventTypes[${index}].endDate is required`);
        }

        // Validate coordinator if provided
        let coordinatorId = null;
        if (type.coordinator) {
          if (!mongoose.Types.ObjectId.isValid(type.coordinator)) {
            throw new Error(`eventTypes[${index}].coordinator must be a valid coordinator ID`);
          }
          const coordinatorExists = await Coordinator.findById(type.coordinator);
          if (!coordinatorExists || coordinatorExists.is_archived) {
            throw new Error(`eventTypes[${index}].coordinator references a coordinator that does not exist`);
          }
          coordinatorId = type.coordinator;
        } else if (existingType && existingType.coordinator) {
          // Preserve existing coordinator if not provided
          coordinatorId = existingType.coordinator;
        }

        const advancesArray = Array.isArray(type.advances) ? type.advances : [];

        const advancesData = advancesArray.map((adv, advIndex) => {
          if (adv.expectedAmount == null) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].expectedAmount is required`);
          }
          if (!adv.advanceDate) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].advanceDate is required`);
          }

          const advanceNumber = adv.advanceNumber != null ? adv.advanceNumber : advIndex + 1;
          
          // Find existing advance to preserve receivedAmount and related fields
          const existingAdvance = existingType
            ? existingType.advances.find(a => a.advanceNumber === advanceNumber)
            : null;

          // Validate modeOfPayment if provided
          if (adv.modeOfPayment && !['cash', 'account'].includes(adv.modeOfPayment.toLowerCase())) {
            throw new Error(`eventTypes[${index}].advances[${advIndex}].modeOfPayment must be 'cash' or 'account'`);
          }

          return {
            advanceNumber,
            expectedAmount: adv.expectedAmount,
            advanceDate: new Date(adv.advanceDate),
            status: existingAdvance ? existingAdvance.status : (adv.status || "Pending"),
            receivedAmount: existingAdvance ? existingAdvance.receivedAmount : (adv.receivedAmount || null),
            receivedDate: existingAdvance ? existingAdvance.receivedDate : (adv.receivedDate ? new Date(adv.receivedDate) : null),
            givenBy: existingAdvance ? existingAdvance.givenBy : (adv.givenBy || null),
            collectedBy: existingAdvance ? existingAdvance.collectedBy : (adv.collectedBy || null),
            modeOfPayment: existingAdvance ? existingAdvance.modeOfPayment : (adv.modeOfPayment ? adv.modeOfPayment.toLowerCase() : null),
            remarks: existingAdvance ? existingAdvance.remarks : (adv.remarks || ""),
            updatedBy: existingAdvance ? existingAdvance.updatedBy : (adv.updatedBy || null),
            updatedAt: existingAdvance ? existingAdvance.updatedAt : (adv.updatedAt ? new Date(adv.updatedAt) : null)
          };
        });

        // Handle amount fields - preserve existing values if not provided
        const existingAmounts = existingType || {};
        const agreedAmount = type.agreedAmount != null ? type.agreedAmount : existingAmounts.agreedAmount;
        const accountAmount = type.accountAmount != null ? type.accountAmount : (existingAmounts.accountAmount ?? 0);
        const accountGst = type.accountGst != null ? type.accountGst : (existingAmounts.accountGst ?? 0);
        const accountAmountWithGst = type.accountAmountWithGst != null ? type.accountAmountWithGst : (existingAmounts.accountAmountWithGst ?? 0);
        const cashAmount = type.cashAmount != null ? type.cashAmount : (existingAmounts.cashAmount ?? 0);
        const totalPayable = type.totalPayable != null ? type.totalPayable : (existingAmounts.totalPayable ?? 0);

        eventTypesData.push({
          eventType: eventTypeId,
          startDate: new Date(type.startDate),
          endDate: new Date(type.endDate),
          venueLocation: type.venueLocation || null,
          subVenueLocation: type.subVenueLocation || null,
          coordinator: coordinatorId,
          agreedAmount: agreedAmount,
          accountAmount: accountAmount,
          accountGst: accountGst,
          accountAmountWithGst: accountAmountWithGst,
          cashAmount: cashAmount,
          totalPayable: totalPayable,
          advances: advancesData
        });
      }

      event.eventTypes = eventTypesData;
    }

    await event.save();

    // Populate eventName, eventType, leads, and venue details before returning
    await event.populate('eventName', 'id name');
    await event.populate('eventTypes.eventType', 'id name event');
    await event.populate('eventTypes.venueLocation', 'id name address city state');
    await event.populate('eventTypes.subVenueLocation', 'id name venue');
    await event.populate('eventTypes.coordinator', 'id name contact_number email');
    await event.populate('lead1', 'id name contact_number email');
    await event.populate('lead2', 'id name contact_number email');
    await event.populate('createdBy', 'id first_name last_name');

    res.status(200).json({ message: "Event updated (received fields preserved)", event });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message || "Server error" });
  }
};
