const STATUS = require("../../utils/statusCodes");
const MESSAGE = require("../../utils/messages");
const mongoose = require('mongoose');

const Request = require("../../Modals/Request");
const { getDataCutoffDate, applyDateFieldCutoff } = require("../../utils/dataCutoff");
const RequestGroupBy = require("../../Modals/RequestGroupBy");
const { validationResult } = require("express-validator");
const jwt = require('jsonwebtoken');
const Department = require("../../Modals/Department");

const JWT_SECRET = process.env.JWT_SECRET;

/** Pagination: default and max page size for request list APIs */
const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_SIZE: 20,
  MAX_SIZE: 100,
  MIN_PAGE: 1,
};

/**
 * Parses and validates pagination query params. Returns { page, size } or null if invalid.
 * @param {object} query - req.query
 * @returns {{ page: number, size: number } | null}
 */
function parsePagination(query) {
  const page = Math.max(PAGINATION.MIN_PAGE, parseInt(query.page, 10) || PAGINATION.DEFAULT_PAGE);
  const size = Math.min(
    PAGINATION.MAX_SIZE,
    Math.max(1, parseInt(query.size, 10) || parseInt(query.limit, 10) || PAGINATION.DEFAULT_SIZE)
  );
  if (page < PAGINATION.MIN_PAGE || size < 1 || size > PAGINATION.MAX_SIZE) return null;
  return { page, size };
}

/**
 * Resolve department query param to ObjectId. Accepts either MongoDB ObjectId or department name (case-insensitive).
 * @param {string} department - department ID or name from query
 * @returns {Promise<ObjectId|null>}
 */
async function resolveDepartmentId(department) {
  if (!department || typeof department !== 'string') return null;
  const trimmed = department.trim();
  if (mongoose.Types.ObjectId.isValid(trimmed) && String(new mongoose.Types.ObjectId(trimmed)) === trimmed) {
    return trimmed;
  }
  const dep = await Department.findOne({ name: { $regex: new RegExp(`^${trimmed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') } }).select('_id').lean();
  return dep ? dep._id : null;
}

module.exports.createRequest = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(STATUS.BAD_REQUEST).json({
            message: 'Bad request',
            errors: errors.array()
        });
    }

    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    // Only DEPARTMENT or ADMIN users can create requests
    if (!['DEPARTMENT', 'ADMIN'].includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({
            message: MESSAGE.unauthorized,
        });
    }

    try {
        const {
            purpose,
            required_date,
            amount,
            priority,
            note,
            remarks,
            transation_in,
            vendor,
            event_reference,
            groupBy,
        } = req.body;

        // Validate amount
        if (isNaN(amount) || parseFloat(amount) <= 0) {
            return res.status(STATUS.VALIDATION_FAILED).json({
                message: 'Invalid amount',
                field: 'amount'
            });
        }

        // Validate required_date if provided
        let requiredDateObj = null;
        if (required_date) {
            requiredDateObj = new Date(required_date);
            if (isNaN(requiredDateObj.getTime())) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid required_date format',
                    field: 'required_date'
                });
            }
        }

        // Get user to fetch their department
        const User = require("../../Modals/User");
        const user = await User.findById(decodedToken.uid);
        
        if (!user) {
            return res.status(STATUS.NOT_FOUND).json({
                message: 'User not found',
            });
        }

        // Extract department from user
        let departmentId = null;
        if (user.department && user.department.department && user.department.department.length > 0) {
            departmentId = user.department.department[0];
        }

        // Validate event_reference if provided
        if (event_reference && !mongoose.Types.ObjectId.isValid(event_reference)) {
            return res.status(STATUS.VALIDATION_FAILED).json({
                message: 'Invalid event_reference ID',
                field: 'event_reference'
            });
        }

        // Verify event exists if event_reference is provided
        if (event_reference) {
            const Event = require("../../Modals/ClientsBookings");
            const eventExists = await Event.findById(event_reference);
            if (!eventExists) {
                return res.status(STATUS.NOT_FOUND).json({
                    message: 'Event not found for given event_reference',
                    field: 'event_reference'
                });
            }
        }

        let groupById = null;
        const rawGroupBy = groupBy !== undefined ? groupBy : req.body.groupby;
        if (rawGroupBy !== undefined && rawGroupBy !== null && String(rawGroupBy).trim() !== '') {
            const gbStr = String(rawGroupBy).trim();
            if (!mongoose.Types.ObjectId.isValid(gbStr)) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid groupBy ID',
                    field: 'groupBy',
                });
            }
            const gbDoc = await RequestGroupBy.findById(gbStr).select('_id').lean();
            if (!gbDoc) {
                return res.status(STATUS.NOT_FOUND).json({
                    message: 'groupBy record not found',
                    field: 'groupBy',
                });
            }
            groupById = gbDoc._id;
        }

        const request = new Request({
            purpose: purpose.trim(),
            required_date: requiredDateObj,
            amount: parseFloat(amount),
            priority: priority || 'MEDIUM',
            note: note ? note.trim() : '',
            requested_by: decodedToken.uid,
            department: departmentId,
            status: 'PENDING',
            transation_in: transation_in || 'CASH',
            remarks: remarks ? String(remarks).trim() : '',
            vendor: vendor || null,
            event_reference: event_reference || null,
            groupBy: groupById,
        });

        const savedRequest = await request.save();

        return res.status(STATUS.CREATED).json({
            message: 'Request created successfully',
            data: {
                id: savedRequest.id,
                purpose: savedRequest.purpose,
                amount: savedRequest.amount,
                required_date: savedRequest.required_date,
                priority: savedRequest.priority,
                note: savedRequest.note,
                remarks: savedRequest.remarks,
                status: savedRequest.status,
                transation_in: savedRequest.transation_in,
                vendor: savedRequest.vendor,
                event_reference: savedRequest.event_reference,
                groupBy: savedRequest.groupBy,
            }
        });
    } catch (error) {
        console.error('Error creating request:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

module.exports.getMyRequests = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    try {
        const page = parseInt(req.query.page) || 1;
        const size = parseInt(req.query.size) || 10;
        const status = req.query.status;

        // Date filter inputs for required_date
        const requiredDateSingle = req.query.required_date ? new Date(req.query.required_date) : null;
        const requiredDateStart = req.query.required_date_start ? new Date(req.query.required_date_start) : null;
        const requiredDateEnd = req.query.required_date_end ? new Date(req.query.required_date_end) : null;

        let query = { 
            requested_by: decodedToken.uid,
            is_archived: false 
        };

        if (status) {
            query.status = status;
        }

        // Required date filtering logic
        if (requiredDateSingle) {
            const startOfDay = new Date(requiredDateSingle);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(requiredDateSingle);
            endOfDay.setHours(23, 59, 59, 999);
            query.required_date = { $gte: startOfDay, $lte: endOfDay };
        } else if (requiredDateStart && requiredDateEnd) {
            query.required_date = { $gte: requiredDateStart, $lte: requiredDateEnd };
        } else if (requiredDateStart) {
            query.required_date = { $gte: requiredDateStart };
        } else if (requiredDateEnd) {
            query.required_date = { $lte: requiredDateEnd };
        }

        applyDateFieldCutoff(query, 'required_date', await getDataCutoffDate());

        const documentCount = await Request.countDocuments(query);
        const requests = await Request.find(query)
            .sort({ createdAt: -1 })
            .skip((page - 1) * size)
            .limit(size)
            .populate('department', 'id name')
            .populate('vendor', 'id name vendor_code')
            .populate('ca_approved_by', 'id first_name last_name email_data designation role')
            .populate({
                path: 'event_reference',
                select: 'id clientName',
                populate: {
                    path: 'eventName',
                    select: 'id name'
                }
            })
            .populate('groupBy', 'id name')
            .exec();

        return res.status(STATUS.SUCCESS).json({
            currentPage: page,
            items: requests,
            totalItems: documentCount,
            totalPages: Math.ceil(documentCount / size)
        });
    } catch (error) {
        console.error('Error fetching requests:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

module.exports.getMyRequestById = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    try {
        const { id } = req.params;

        const request = await Request.findOne({
            _id: id,
            requested_by: decodedToken.uid,
            is_archived: false
        })
            .populate('requested_by', 'id first_name last_name')
            .populate('department', 'id name')
            .populate('vendor', 'id name vendor_code')
            .populate('ca_approved_by', 'id first_name last_name email_data designation role')
            .populate({
                path: 'event_reference',
                select: 'id clientName',
                populate: {
                    path: 'eventName',
                    select: 'id name'
                }
            })
            .populate('groupBy', 'id name')
            .exec();

        if (!request) {
            return res.status(STATUS.NOT_FOUND).json({
                message: 'Request not found',
            });
        }

        return res.status(STATUS.SUCCESS).json({
            data: request,
            message: "Request Found"
        });
    } catch (error) {
        console.error('Error fetching request:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};


module.exports.getAllRequests = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);
  
    // Only OWNER, ADMIN, DEPARTMENT, APPROVER, CA can view all requests
    if (!['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER', 'CA'].includes(decodedToken.role)) {
      return res.status(STATUS.UNAUTHORISED).json({
        message: MESSAGE.unauthorized,
      });
    }
  
    try {
      const pagination = parsePagination(req.query);
      if (!pagination) {
        return res.status(STATUS.BAD_REQUEST).json({
          message: 'Invalid pagination',
          details: `page must be >= ${PAGINATION.MIN_PAGE}, size between 1 and ${PAGINATION.MAX_SIZE}`,
        });
      }
      const { page, size } = pagination;

      const status = req.query.status;
      const priority = req.query.priority;
      const department = req.query.department;
      const accountsCheck = req.query.accounts_check;
      const caCheck = req.query.ca_check;
      const ownerCheck = req.query.owner_check;
      const approverCheck = req.query.approver_check;
      const eventId = req.query.event || req.query.eventId;
      const vendorId = req.query.vendor || req.query.vendorId;
      const groupByFilter = (req.query.groupBy || req.query.groupby || '').toString().trim();
      const search = req.query.search?.trim();
  
      // Date filter for createdAt (startDate, endDate)
      const parseDate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return Number.isNaN(d.getTime()) ? null : d;
      };
      const startDate = parseDate(req.query.startDate);
      const endDate = parseDate(req.query.endDate);
  
      // Required date filter (start and end only)
      const requiredDateStart = parseDate(req.query.required_date_start);
      const requiredDateEnd = parseDate(req.query.required_date_end);
  
      // include docs where is_archived is false or missing
      let query = { is_archived: { $ne: true } };
  
      // Apply filters (department: ID or name, e.g. ACCOUNTS)
      if (status) query.status = status;
      if (priority) query.priority = priority;
      const departmentId = await resolveDepartmentId(department);
      if (departmentId) query.department = departmentId;
      if (accountsCheck) query.accounts_check = accountsCheck;
      if (caCheck) query.ca_check = caCheck;
      if (ownerCheck) query.owner_check = ownerCheck;
      if (approverCheck) query.approver_check = approverCheck;
      if (eventId && mongoose.Types.ObjectId.isValid(eventId)) query.event_reference = eventId;
      if (vendorId && mongoose.Types.ObjectId.isValid(vendorId)) query.vendor = vendorId;
      if (groupByFilter && mongoose.Types.ObjectId.isValid(groupByFilter)) {
        query.groupBy = new mongoose.Types.ObjectId(groupByFilter);
      }
  
      // Date filtering for createdAt (startDate, endDate)
      if (startDate && endDate) {
        query.createdAt = { $gte: startDate, $lte: endDate };
      } else if (startDate) {
        query.createdAt = { $gte: startDate };
      } else if (endDate) {
        query.createdAt = { $lte: endDate };
      }

      // Required date filtering (start and end only)
      if (requiredDateStart && requiredDateEnd) {
        query.required_date = { $gte: requiredDateStart, $lte: requiredDateEnd };
      } else if (requiredDateStart) {
        query.required_date = { $gte: requiredDateStart };
      } else if (requiredDateEnd) {
        query.required_date = { $lte: requiredDateEnd };
      }

      applyDateFieldCutoff(query, 'required_date', await getDataCutoffDate());
  
      // Search filter in multiple fields, including department name
      let departmentIds = [];
      if (search) {
        // Find matching departments by name (case-insensitive)
        const matchingDepts = await Department.find(
          { name: { $regex: search, $options: 'i' } },
          '_id'
        );
        departmentIds = matchingDepts.map((dep) => dep._id);
  
        // Build $or filters
        query.$or = [
          { title: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } },
          { 'requested_by.first_name': { $regex: search, $options: 'i' } },
          { 'requested_by.last_name': { $regex: search, $options: 'i' } },
          { 'requested_by.email_data': { $regex: search, $options: 'i' } },
        ];
  
        // Allow search by department name as well
        if (departmentIds.length) {
          query.$or.push({ department: { $in: departmentIds } });
        }
      }
  
      const [documentCount, requests] = await Promise.all([
        Request.countDocuments(query),
        Request.find(query)
          .sort({ createdAt: -1 })
          .skip((page - 1) * size)
          .limit(size)
          .populate('requested_by', 'id first_name last_name email_data designation')
          .populate('department', 'id name')
          .populate('vendor', 'id name vendor_code')
          .populate('ca_approved_by', 'id first_name last_name email_data designation role')
          .populate('event_reference', 'id clientName name')
          .populate('groupBy', 'id name')
          .lean()
          .exec(),
      ]);

      const departmentWiseItems = requests.reduce((acc, reqItem) => {
        const depName =
          (reqItem.department && reqItem.department.name) || 'Unassigned';
        if (!acc[depName]) acc[depName] = [];
        acc[depName].push(reqItem);
        return acc;
      }, {});

      const totalPages = Math.ceil(documentCount / size) || 1;

      return res.status(STATUS.SUCCESS).json({
        items: requests,
        departmentWiseItems,
        totalItems: documentCount,
        pagination: {
          currentPage: page,
          totalPages,
          size,
          hasNextPage: page < totalPages,
          hasPreviousPage: page > 1,
        },
      });
    } catch (error) {
      console.error('Error fetching requests:', error);
      return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
        message: MESSAGE.internalServerError,
        error: error.message,
      });
    }
  }

// module.exports.getAllRequests = async (req, res) => {
//     const token = req.get('Authorization');
//     let decodedToken = await jwt.decode(token);
  
//     // Only OWNER, ADMIN, DEPARTMENT, APPROVER can view all requests
//     if (!['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER'].includes(decodedToken.role)) {
//       return res.status(STATUS.UNAUTHORISED).json({
//         message: MESSAGE.unauthorized,
//       });
//     }
  
//     try {
//       const page = parseInt(req.query.page) || 1;
//       const size = parseInt(req.query.size) || 10;
//       const status = req.query.status;
//       const priority = req.query.priority;
//       const department = req.query.department;
//       const search = req.query.search?.trim();
  
//       // Date filter inputs
//       const startDate = req.query.startDate ? new Date(req.query.startDate) : null;
//       const endDate = req.query.endDate ? new Date(req.query.endDate) : null;
//       const singleDate = req.query.date ? new Date(req.query.date) : null;
  
//       let query = { is_archived: false };
  
//       // Apply filters
//       if (status) query.status = status;
//       if (priority) query.priority = priority;
//       if (department) query.department = department;
  
//       // Date filtering logic
//       if (singleDate) {
//         const startOfDay = new Date(singleDate);
//         startOfDay.setHours(0, 0, 0, 0);
  
//         const endOfDay = new Date(singleDate);
//         endOfDay.setHours(23, 59, 59, 999);
  
//         query.createdAt = { $gte: startOfDay, $lte: endOfDay };
//       } else if (startDate && endDate) {
//         query.createdAt = { $gte: startDate, $lte: endDate };
//       } else if (startDate) {
//         query.createdAt = { $gte: startDate };
//       } else if (endDate) {
//         query.createdAt = { $lte: endDate };
//       }
  
//       // Search filter in multiple fields, including department name
//       let departmentIds = [];
//       if (search) {
//         // Find matching departments by name (case-insensitive)
//         const matchingDepts = await Department.find({
//           name: { $regex: search, $options: 'i' }
//         }, '_id');
//         departmentIds = matchingDepts.map(dep => dep._id);
  
//         // Build $or filters
//         query.$or = [
//           { title: { $regex: search, $options: 'i' } },
//           { description: { $regex: search, $options: 'i' } },
//           { 'requested_by.first_name': { $regex: search, $options: 'i' } },
//           { 'requested_by.last_name': { $regex: search, $options: 'i' } },
//           { 'requested_by.email_data': { $regex: search, $options: 'i' } },
//         ];
  
//         // Allow search by department name as well
//         if (departmentIds.length) {
//           query.$or.push({ department: { $in: departmentIds } });
//         }
//       }
  
//       const documentCount = await Request.countDocuments(query);
//       const requests = await Request.find(query)
//         .sort({ createdAt: -1 })
//         .skip((page - 1) * size)
//         .limit(size)
//         .populate('requested_by', 'id first_name last_name email_data designation')
//         .populate('department', 'id name')
//         .populate('vendor', 'id name')
//         .exec();
  
//       return res.status(STATUS.SUCCESS).json({
//         currentPage: page,
//         items: requests,
//         totalItems: documentCount,
//         totalPages: Math.ceil(documentCount / size),
//       });
//     } catch (error) {
//       console.error('Error fetching requests:', error);
//       return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
//         message: MESSAGE.internalServerError,
//         error: error.message,
//       });
//     }
//   }

module.exports.getRequestById = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    // Only OWNER, ADMIN, and CA can view specific request details
    if (!['OWNER', 'ADMIN', 'CA'].includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({
            message: MESSAGE.unauthorized,
        });
    }

    try {
        const { id } = req.params;

        const request = await Request.findOne({
            _id: id,
            is_archived: false
        })
            .populate('requested_by', 'id first_name last_name email_data designation')
            .populate('department', 'id name')
            .populate('vendor', 'id name vendor_code')
            .populate('ca_approved_by', 'id first_name last_name email_data designation role')
            .populate({
                path: 'event_reference',
                select: 'id clientName',
                populate: {
                    path: 'eventName',
                    select: 'id name'
                }
            })
            .populate('groupBy', 'id name')
            .exec();

        if (!request) {
            return res.status(STATUS.NOT_FOUND).json({
                message: 'Request not found',
            });
        }

        return res.status(STATUS.SUCCESS).json({
            data: request,
            message: "Request Found"
        });
    } catch (error) {
        console.error('Error fetching request:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

module.exports.updateRequest = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    if (!['OWNER', 'DEPARTMENT', 'APPROVER', 'CA'].includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({
            message: MESSAGE.unauthorized,
        });
    }

    try {
        const { id } = req.params;
        const {
            status,
            amount_paid,
            planned_amount,
            approver_amount,
            entity_account,
            amount_paid_to,
            remarks,
            is_active,
            ca_approved,
            groupBy,
        } = req.body;

        const request = await Request.findById(id);
        if (!request) {
            return res.status(STATUS.NOT_FOUND).json({
                message: 'Request not found',
            });
        }

        const updateData = {};

        if (status !== undefined) {
            if (!['PENDING', 'APPROVED', 'REJECTED', 'COMPLETED'].includes(status)) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid status. Must be: PENDING, APPROVED, REJECTED, COMPLETED',
                    field: 'status'
                });
            }
            updateData.status = status;

            // Set approval status strings based on user role and status
            if (status === 'COMPLETED' || status === 'APPROVED') {
                if (decodedToken.role === 'DEPARTMENT') {
                    updateData.accounts_check = 'APPROVED';
                } else if (decodedToken.role === 'OWNER') {
                    updateData.owner_check = 'APPROVED';
                } else if (decodedToken.role === 'APPROVER') {
                    updateData.approver_check = 'APPROVED';
                } else if (decodedToken.role === 'CA') {
                    updateData.ca_check = 'APPROVED';
                    updateData.ca_approved = true;
                    updateData.ca_approved_by = decodedToken.uid;
                    updateData.ca_approved_at = new Date();
                }
            } else if (status === 'REJECTED') {
                if (decodedToken.role === 'DEPARTMENT') {
                    updateData.accounts_check = 'REJECTED';
                } else if (decodedToken.role === 'OWNER') {
                    updateData.owner_check = 'REJECTED';
                } else if (decodedToken.role === 'APPROVER') {
                    updateData.approver_check = 'REJECTED';
                } else if (decodedToken.role === 'CA') {
                    updateData.ca_check = 'REJECTED';
                    updateData.ca_approved = false;
                    updateData.ca_approved_by = decodedToken.uid;
                    updateData.ca_approved_at = new Date();
                }
            } else if (status === 'PENDING') {
                // Reset CA approval if status is set back to PENDING
                if (decodedToken.role === 'CA') {
                    updateData.ca_check = 'PENDING';
                    updateData.ca_approved = false;
                    updateData.ca_approved_by = null;
                    updateData.ca_approved_at = null;
                }
            }
        }

        if (amount_paid !== undefined) {
            const amount = parseFloat(amount_paid);
            if (isNaN(amount) || amount < 0) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid amount paid',
                    field: 'amount_paid'
                });
            }
            updateData.amount_paid = amount;
            updateData.total_amount_paid = (request.total_amount_paid || 0) + amount;
        }

        if (planned_amount !== undefined) {
            const plannedAmt = parseFloat(planned_amount);
            if (isNaN(plannedAmt) || plannedAmt < 0) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid planned amount',
                    field: 'planned_amount'
                });
            }
            updateData.planned_amount = plannedAmt;
        }

        // Only APPROVER, OWNER, and CA roles can set approver_amount
        if (approver_amount !== undefined) {
            if (!['OWNER', 'APPROVER', 'CA'].includes(decodedToken.role)) {
                return res.status(STATUS.UNAUTHORISED).json({
                    message: 'Only OWNER, APPROVER, and CA roles can set approver_amount',
                });
            }
            const approverAmt = parseFloat(approver_amount);
            if (isNaN(approverAmt) || approverAmt < 0) {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid approver amount',
                    field: 'approver_amount'
                });
            }
            updateData.approver_amount = approverAmt;
        }
        if (entity_account !== undefined) {
            updateData.entity_account = entity_account;
        }
        if (amount_paid_to !== undefined) {
            updateData.amount_paid_to = amount_paid_to;
        }
        if (remarks !== undefined) {
            updateData.remarks = remarks.trim();
        }

        if (is_active !== undefined) {
            updateData.is_active = is_active;
        }

        // Handle CA approval directly (if CA role is updating)
        if (ca_approved !== undefined && decodedToken.role === 'CA') {
            if (typeof ca_approved !== 'boolean') {
                return res.status(STATUS.VALIDATION_FAILED).json({
                    message: 'Invalid ca_approved value. Must be a boolean',
                    field: 'ca_approved'
                });
            }
            
            updateData.ca_approved = ca_approved;
            updateData.ca_approved_by = decodedToken.uid;
            updateData.ca_approved_at = new Date();
            
            // Update ca_check based on ca_approved value
            if (ca_approved) {
                updateData.ca_check = 'APPROVED';
                // If status is not set, set it to APPROVED
                if (status === undefined) {
                    updateData.status = 'APPROVED';
                }
            } else {
                updateData.ca_check = 'REJECTED';
                // If status is not set, set it to REJECTED
                if (status === undefined) {
                    updateData.status = 'REJECTED';
                }
            }
        } else if (ca_approved !== undefined && decodedToken.role !== 'CA') {
            // Only CA role can set ca_approved
            return res.status(STATUS.UNAUTHORISED).json({
                message: 'Only CA role can set ca_approved field',
            });
        }

        if (groupBy !== undefined || req.body.groupby !== undefined) {
            const rawGb = groupBy !== undefined ? groupBy : req.body.groupby;
            if (rawGb === null || rawGb === '') {
                updateData.groupBy = null;
            } else {
                const gbStr = String(rawGb).trim();
                if (!mongoose.Types.ObjectId.isValid(gbStr)) {
                    return res.status(STATUS.VALIDATION_FAILED).json({
                        message: 'Invalid groupBy ID',
                        field: 'groupBy',
                    });
                }
                const gbDoc = await RequestGroupBy.findById(gbStr).select('_id').lean();
                if (!gbDoc) {
                    return res.status(STATUS.NOT_FOUND).json({
                        message: 'groupBy record not found',
                        field: 'groupBy',
                    });
                }
                updateData.groupBy = gbDoc._id;
            }
        }

        updateData.handled_by = decodedToken.uid;

        if (Object.keys(updateData).length === 0) {
            return res.status(STATUS.BAD_REQUEST).json({
                message: 'No fields provided to update',
            });
        }

        const updatedRequest = await Request.findByIdAndUpdate(
            id,
            updateData,
            { new: true }
        )
            .populate('requested_by', 'id first_name last_name email_data designation')
            .populate('department', 'id name')
            .populate('vendor', 'id name vendor_code')
            .populate('ca_approved_by', 'id first_name last_name email_data designation role')
            .populate({
                path: 'event_reference',
                select: 'id clientName',
                populate: {
                    path: 'eventName',
                    select: 'id name'
                }
            })
            .populate('groupBy', 'id name')
            .exec();

        return res.status(STATUS.SUCCESS).json({
            data: updatedRequest,
            message: "Request Updated Successfully"
        });

    } catch (error) {
        console.error('Error updating request:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

// module.exports.updateRequest = async (req, res) => {
//     const token = req.get('Authorization');
//     let decodedToken = await jwt.decode(token);

//     // Only OWNER and ADMIN can update requests
//     if (!['OWNER', 'DEPARTMENT','APPROVER'].includes(decodedToken.role)) {
//         return res.status(STATUS.UNAUTHORISED).json({
//             message: MESSAGE.unauthorized,
//         });
//     }

//     try {
//         const { id } = req.params;
//         const {
//             status,
//             amount_paid,
//             remarks,
//             is_active
//         } = req.body;

//         const request = await Request.findById(id);

//         if (!request) {
//             return res.status(STATUS.NOT_FOUND).json({
//                 message: 'Request not found',
//             });
//         }

//         // Build update data object with only provided fields
//         const updateData = {};

//         // Update status if provided
//         if (status !== undefined) {
//             if (!['PENDING', 'APPROVED', 'REJECTED', 'COMPLETED'].includes(status)) {
//                 return res.status(STATUS.VALIDATION_FAILED).json({
//                     message: 'Invalid status. Must be: PENDING, APPROVED, REJECTED, COMPLETED',
//                     field: 'status'
//                 });
//             }
//             updateData.status = status;
//         }

//         // Update amount received status
//         if (amount_paid !== undefined) {
//             updateData.amount_paid = amount_paid;
//         }

//         // Update amount paid (adds to total)
//         if (amount_paid !== undefined) {
//             const amount = parseFloat(amount_paid);
//             if (isNaN(amount) || amount < 0) {
//                 return res.status(STATUS.VALIDATION_FAILED).json({
//                     message: 'Invalid amount paid',
//                     field: 'amount_paid'
//                 });
//             }
//             updateData.amount_paid = amount;
//             // Add to total amount paid
//             updateData.total_amount_paid = (request.total_amount_paid || 0) + amount;
//         }

//         // Update remarks
//         if (remarks !== undefined) {
//             updateData.remarks = remarks.trim();
//         }

//         // Update is_active status
//         if (is_active !== undefined) {
//             updateData.is_active = is_active;
//         }

//         // Track who made the update
//         updateData.handled_by = decodedToken.uid;

//         // If no fields to update, return early
//         if (Object.keys(updateData).length === 0) {
//             return res.status(STATUS.BAD_REQUEST).json({
//                 message: 'No fields provided to update',
//             });
//         }

//         const updatedRequest = await Request.findByIdAndUpdate(
//             id,
//             updateData,
//             { new: true }
//         )
//             .populate('requested_by', 'id first_name last_name email_data designation')
//             .populate('department', 'id name')
//             // .populate('handled_by', 'id first_name last_name')
//             .populate('vendor', 'id name')
//             .exec();

//         return res.status(STATUS.SUCCESS).json({
//             data: updatedRequest,
//             message: "Request Updated Successfully"
//         });
//     } catch (error) {
//         console.error('Error updating request:', error);
//         return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
//             message: MESSAGE.internalServerError,
//             error: error.message,
//         });
//     }
// };

module.exports.archiveRequest = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);

    // Only OWNER and ADMIN can archive requests
    if (!['OWNER', 'ADMIN'].includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({
            message: MESSAGE.unauthorized,
        });
    }

    try {
        const { id } = req.params;

        const request = await Request.findById(id);

        if (!request) {
            return res.status(STATUS.NOT_FOUND).json({
                message: 'Request not found',
            });
        }

        const updatedRequest = await Request.findByIdAndUpdate(
            id,
            { is_archived: !request.is_archived },
            { new: true }
        )
            .populate('requested_by', 'id first_name last_name email_data designation')
            .populate('department', 'id name')
            .populate('vendor', 'id name vendor_code')
            .populate('ca_approved_by', 'id first_name last_name email_data designation role')
            .populate({
                path: 'event_reference',
                select: 'id clientName',
                populate: {
                    path: 'eventName',
                    select: 'id name'
                }
            })
            .populate('groupBy', 'id name')
            .exec();

        return res.status(STATUS.SUCCESS).json({
            id: updatedRequest.id,
            is_archived: updatedRequest.is_archived,
            message: updatedRequest.is_archived 
                ? "Request Archived Successfully" 
                : "Request Restored Successfully"
        });
    } catch (error) {
        console.error('Error archiving request:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

module.exports.deleteRequest = async (req, res) => {
    const token = req.get('Authorization');
    const decodedToken = await jwt.decode(token);

    // Allow any authenticated role to delete requests
    if (!decodedToken?.role) {
        return res.status(STATUS.UNAUTHORISED).json({
            message: MESSAGE.unauthorized,
        });
    }

    try {
        const { id } = req.params;
        if (!id || !mongoose.Types.ObjectId.isValid(id)) {
            return res.status(STATUS.BAD_REQUEST).json({
                message: 'Valid request id is required',
            });
        }

        const deleted = await Request.findByIdAndDelete(id);
        if (!deleted) {
            return res.status(404).json({
                message: 'Request not found',
            });
        }

        return res.status(STATUS.SUCCESS).json({
            message: 'Request deleted successfully',
            id: String(id),
        });
    } catch (error) {
        console.error('deleteRequest:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};



// module.exports.getRequests = async (req, res) => {
//     const token = req.get('Authorization');
//     let decodedToken = await jwt.decode(token);

//     // Only OWNER and ADMIN can view all requests
//     if (!['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER'].includes(decodedToken.role)) {
//         return res.status(STATUS.UNAUTHORISED).json({
//             message: MESSAGE.unauthorized,
//         });
//     }

//     try {
//         const status = req.query.status;
//         const priority = req.query.priority;
//         const department = req.query.department;

//         let query = { is_archived: false };

//         if (status) {
//             query.status = status;
//         }

//         if (priority) {
//             query.priority = priority;
//         }

//         if (department) {
//             query.department = department;
//         }

//         const documentCount = await Request.countDocuments(query);
//         const requests = await Request.find(query)
//             .sort({ createdAt: -1 })
//             // Removed skip() and limit()
//             .populate('requested_by', 'id first_name last_name email_data designation')
//             .populate('department', 'id name')
//             //.populate('handled_by', 'id first_name last_name')
//             .populate('vendor', 'id name')
//             .exec();

//         return res.status(STATUS.SUCCESS).json({
//             items: requests,
//             totalItems: documentCount,
//         });
//     } catch (error) {
//         console.error('Error fetching requests:', error);
//         return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
//             message: MESSAGE.internalServerError,
//             error: error.message,
//         });
//     }
// };

// module.exports.getRequests = async (req, res) => {
//     const token = req.get('Authorization');
//     let decodedToken = await jwt.decode(token);
  
//     // Only OWNER, ADMIN, DEPARTMENT, APPROVER can view all requests
//     if (!['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER'].includes(decodedToken.role)) {
//       return res.status(STATUS.UNAUTHORISED).json({
//         message: MESSAGE.unauthorized,
//       });
//     }
  
//     try {
//       const status = req.query.status;
//       const priority = req.query.priority;
//       const department = req.query.department;
//       const search = req.query.search?.trim();
  
//       const startDate = req.query.startDate ? new Date(req.query.startDate) : null;
//       const endDate = req.query.endDate ? new Date(req.query.endDate) : null;
//       const singleDate = req.query.date ? new Date(req.query.date) : null;
  
//       // Required date filter inputs
//       const requiredDateSingle = req.query.required_date ? new Date(req.query.required_date) : null;
//       const requiredDateStart = req.query.required_date_start ? new Date(req.query.required_date_start) : null;
//       const requiredDateEnd = req.query.required_date_end ? new Date(req.query.required_date_end) : null;
  
//       let query = { is_archived: false };
  
//       if (status) query.status = status;
//       if (priority) query.priority = priority;
//       if (department) query.department = department;
  
//       // Date filtering for createdAt
//       if (singleDate) {
//         const startOfDay = new Date(singleDate);
//         startOfDay.setHours(0, 0, 0, 0);
  
//         const endOfDay = new Date(singleDate);
//         endOfDay.setHours(23, 59, 59, 999);
  
//         query.createdAt = { $gte: startOfDay, $lte: endOfDay };
//       } else if (startDate && endDate) {
//         query.createdAt = { $gte: startDate, $lte: endDate };
//       } else if (startDate) {
//         query.createdAt = { $gte: startDate };
//       } else if (endDate) {
//         query.createdAt = { $lte: endDate };
//       }

//       // Required date filtering logic
//       if (requiredDateSingle) {
//         const startOfDay = new Date(requiredDateSingle);
//         startOfDay.setHours(0, 0, 0, 0);
//         const endOfDay = new Date(requiredDateSingle);
//         endOfDay.setHours(23, 59, 59, 999);
//         query.required_date = { $gte: startOfDay, $lte: endOfDay };
//       } else if (requiredDateStart && requiredDateEnd) {
//         query.required_date = { $gte: requiredDateStart, $lte: requiredDateEnd };
//       } else if (requiredDateStart) {
//         query.required_date = { $gte: requiredDateStart };
//       } else if (requiredDateEnd) {
//         query.required_date = { $lte: requiredDateEnd };
//       }
  
//       // Search filter
//       if (search) {
//         query.$or = [
//           { title: { $regex: search, $options: 'i' } },
//           { description: { $regex: search, $options: 'i' } },
//           { 'requested_by.first_name': { $regex: search, $options: 'i' } },
//           { 'requested_by.last_name': { $regex: search, $options: 'i' } },
//           { 'requested_by.email_data': { $regex: search, $options: 'i' } },
//         ];
//       }
  
//       const documentCount = await Request.countDocuments(query);
//       const requests = await Request.find(query)
//         .sort({ createdAt: -1 })
//         // skip() and limit() removed as per your original version
//         .populate('requested_by', 'id first_name last_name email_data designation')
//         .populate('department', 'id name')
//         //.populate('handled_by', 'id first_name last_name')
//         .populate('vendor', 'id name')
//         .populate('event_reference', 'id clientName name')
//         .exec();
  
//       return res.status(STATUS.SUCCESS).json({
//         items: requests,
//         totalItems: documentCount,
//       });
//     } catch (error) {
//       console.error('Error fetching requests:', error);
//       return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
//         message: MESSAGE.internalServerError,
//         error: error.message,
//       });
//     }
//   };

module.exports.getRequests = async (req, res) => {
    const token = req.get('Authorization');
    let decodedToken = await jwt.decode(token);
  
    // Only OWNER, ADMIN, DEPARTMENT, APPROVER, CA can view all requests
    if (!['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER', 'CA'].includes(decodedToken.role)) {
      return res.status(STATUS.UNAUTHORISED).json({
        message: MESSAGE.unauthorized,
      });
    }
  
    try {
      const pagination = parsePagination(req.query);
      if (!pagination) {
        return res.status(STATUS.BAD_REQUEST).json({
          message: 'Invalid pagination',
          details: `page must be >= ${PAGINATION.MIN_PAGE}, size between 1 and ${PAGINATION.MAX_SIZE}`,
        });
      }
      const { page, size } = pagination;

      const status = req.query.status;
      const priority = req.query.priority;
      const department = req.query.department;
      const accountsCheck = req.query.accounts_check;
      const caCheck = req.query.ca_check;
      const ownerCheck = req.query.owner_check;
      const approverCheck = req.query.approver_check;
      const eventId = req.query.event || req.query.eventId;
      const vendorId = req.query.vendor || req.query.vendorId;
      const groupByFilter = (req.query.groupBy || req.query.groupby || '').toString().trim();
      const search = req.query.search?.trim();

      const parseDate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return Number.isNaN(d.getTime()) ? null : d;
      };

      const startDate = parseDate(req.query.startDate);
      const endDate = parseDate(req.query.endDate);

      // Required date filter inputs (start/end only)
      const requiredDateStart = parseDate(req.query.required_date_start);
      const requiredDateEnd = parseDate(req.query.required_date_end);

      // include docs where is_archived is false or missing
      let query = { is_archived: { $ne: true } };
  
      if (status) query.status = status;
      if (priority) query.priority = priority;
      const departmentId = await resolveDepartmentId(department);
      if (departmentId) query.department = departmentId;
      if (accountsCheck) query.accounts_check = accountsCheck;
      if (caCheck) query.ca_check = caCheck;
      if (ownerCheck) query.owner_check = ownerCheck;
      if (approverCheck) query.approver_check = approverCheck;
      if (eventId && mongoose.Types.ObjectId.isValid(eventId)) query.event_reference = eventId;
      if (vendorId && mongoose.Types.ObjectId.isValid(vendorId)) query.vendor = vendorId;
      if (groupByFilter && mongoose.Types.ObjectId.isValid(groupByFilter)) {
        query.groupBy = new mongoose.Types.ObjectId(groupByFilter);
      }
  
      // Date filtering for createdAt (start/end only)
      if (startDate && endDate) {
        query.createdAt = { $gte: startDate, $lte: endDate };
      } else if (startDate) {
        query.createdAt = { $gte: startDate };
      } else if (endDate) {
        query.createdAt = { $lte: endDate };
      }

      // Required date filtering logic (start/end only)
      if (requiredDateStart && requiredDateEnd) {
        query.required_date = { $gte: requiredDateStart, $lte: requiredDateEnd };
      } else if (requiredDateStart) {
        query.required_date = { $gte: requiredDateStart };
      } else if (requiredDateEnd) {
        query.required_date = { $lte: requiredDateEnd };
      }

      applyDateFieldCutoff(query, 'required_date', await getDataCutoffDate());
  
      // Search filter
      if (search) {
        query.$or = [
          { title: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } },
          { 'requested_by.first_name': { $regex: search, $options: 'i' } },
          { 'requested_by.last_name': { $regex: search, $options: 'i' } },
          { 'requested_by.email_data': { $regex: search, $options: 'i' } },
        ];
      }
 
      // Efficient DB-side pagination: only fetch one page, not all documents
      const [documentCount, requests] = await Promise.all([
        Request.countDocuments(query),
        Request.find(query)
          .sort({ createdAt: -1 })
          .skip((page - 1) * size)
          .limit(size)
          .populate('requested_by', 'id first_name last_name email_data designation')
          .populate('department', 'id name')
          .populate('vendor', 'id name vendor_code')
          .populate('ca_approved_by', 'id first_name last_name email_data designation role')
          .populate('event_reference', 'id clientName name')
          .populate('groupBy', 'id name')
          .lean()
          .exec(),
      ]);

      // Group only the current page by department for response shape
      const departmentWiseItems = requests.reduce((acc, reqItem) => {
        const depName =
          (reqItem.department && reqItem.department.name) || 'Unassigned';
        if (!acc[depName]) acc[depName] = [];
        acc[depName].push(reqItem);
        return acc;
      }, {});

      const totalPages = Math.ceil(documentCount / size) || 1;

      return res.status(STATUS.SUCCESS).json({
        departments: departmentWiseItems,
        pagination: {
          currentPage: page,
          totalPages,
          size,
          totalItems: documentCount,
          hasNextPage: page < totalPages,
          hasPreviousPage: page > 1,
        },
        totalItems: documentCount,
      });
    } catch (error) {
      console.error('Error fetching requests:', error);
      return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
        message: MESSAGE.internalServerError,
        error: error.message,
      });
    }
  };  



exports.getRequestsByDepartmentId = async (req, res) => {
    try {
        const departmentId = req.params.id;

        // Validate departmentId is a valid ObjectId
        if (!mongoose.Types.ObjectId.isValid(departmentId)) {
            return res.status(STATUS.BAD_REQUEST).json({ message: "Invalid department ID" });
        }

        // Find all requests with the specified department, active and not archived
        const cutoff = await getDataCutoffDate();
        const deptQuery = {
            department: departmentId,
            is_active: true,
            is_archived: false
        };
        applyDateFieldCutoff(deptQuery, 'required_date', cutoff);

        const requests = await Request.find(deptQuery)
        .sort({ createdAt: -1 })
        .populate('requested_by', 'id first_name last_name email_data designation')
        .populate('department', 'id name')
        .populate('vendor', 'id name vendor_code')
        .populate('ca_approved_by', 'id first_name last_name email_data designation role')
        .populate('event_reference', 'id clientName name')
        .populate('groupBy', 'id name')
        .exec();

        if (!requests.length) {
            return res.status(STATUS.NOT_FOUND).json({ message: "No requests found for this department" });
        }

        return res.status(STATUS.SUCCESS).json({ requests });

    } catch (error) {
        console.error('Error fetching requests by department:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({ error: error.message });
    }
};

const GROUP_BY_READ_ROLES = ['OWNER', 'ADMIN', 'DEPARTMENT', 'APPROVER', 'CA'];
const GROUP_BY_WRITE_ROLES = ['OWNER', 'ADMIN', 'DEPARTMENT'];
const GROUP_BY_DELETE_ROLES = ['OWNER', 'ADMIN'];

/** GET /request/group-by — list all group labels (sorted by name). */
module.exports.listRequestGroupBy = async (req, res) => {
    const token = req.get('Authorization');
    const decodedToken = jwt.decode(token);
    if (!decodedToken?.role || !GROUP_BY_READ_ROLES.includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({ message: MESSAGE.unauthorized });
    }
    try {
        const items = await RequestGroupBy.find({})
            .sort({ name: 1 })
            .lean()
            .maxTimeMS(15000);
        return res.status(STATUS.SUCCESS).json({
            items: items.map((r) => ({
                _id: String(r._id),
                id: r._id,
                name: r.name,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
            })),
        });
    } catch (error) {
        console.error('listRequestGroupBy:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

/** POST /request/group-by — create a group label (unique name). */
module.exports.createRequestGroupBy = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(STATUS.BAD_REQUEST).json({ message: 'Bad request', errors: errors.array() });
    }
    const token = req.get('Authorization');
    const decodedToken = jwt.decode(token);
    if (!decodedToken?.role || !GROUP_BY_WRITE_ROLES.includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({ message: MESSAGE.unauthorized });
    }
    try {
        const name = String(req.body.name || '').trim();
        if (!name) {
            return res.status(STATUS.BAD_REQUEST).json({ message: 'name is required' });
        }
        const created = await RequestGroupBy.create({ name });
        const j = created.toJSON ? created.toJSON() : created;
        return res.status(STATUS.CREATED).json({
            message: 'Group created',
            item: {
                _id: String(j._id || j.id),
                id: j._id || j.id,
                name: j.name,
                createdAt: j.createdAt,
                updatedAt: j.updatedAt,
            },
        });
    } catch (error) {
        if (error && error.code === 11000) {
            return res.status(409).json({
                message: 'A group with this name already exists',
                field: 'name',
            });
        }
        console.error('createRequestGroupBy:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

/** DELETE /request/group-by/:id — delete a group label if no request references it. */
module.exports.deleteRequestGroupBy = async (req, res) => {
    const token = req.get('Authorization');
    const decodedToken = jwt.decode(token);
    if (!decodedToken?.role || !GROUP_BY_DELETE_ROLES.includes(decodedToken.role)) {
        return res.status(STATUS.UNAUTHORISED).json({ message: MESSAGE.unauthorized });
    }
    const { id } = req.params;
    if (!id || !mongoose.Types.ObjectId.isValid(id)) {
        return res.status(STATUS.BAD_REQUEST).json({ message: 'Valid id is required' });
    }
    try {
        const existing = await RequestGroupBy.findById(id).lean();
        if (!existing) {
            return res.status(404).json({ message: 'Group not found' });
        }
        const refCount = await Request.countDocuments({ groupBy: id });
        if (refCount > 0) {
            return res.status(409).json({
                message: 'Cannot delete: one or more requests still use this group',
                requestsReferencing: refCount,
            });
        }
        await RequestGroupBy.deleteOne({ _id: id });
        return res.status(STATUS.SUCCESS).json({ message: 'Group deleted', id: String(id) });
    } catch (error) {
        console.error('deleteRequestGroupBy:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};

/** Max ids per PATCH /request/ca-check/bulk call. */
const CA_BULK_MAX_IDS = 200;
/** Parallel per-id updates inside one bulk call. */
const CA_BULK_CONCURRENCY = 10;

/**
 * PATCH /request/ca-check/bulk
 * Body: { ids: [requestId], ca_check: "APPROVED" | "REJECTED" }
 * → 200 { updated: [id], failed: [{ id, message }] }
 *
 * Applies, per id, exactly what PATCH /request/:id does for a CA sending
 * { ca_approved: true|false }: ca_check, ca_approved, ca_approved_by, ca_approved_at,
 * status (APPROVED / REJECTED) and handled_by.
 * Only requests whose ca_check is currently PENDING change. Each id is updated atomically
 * on its own, and one bad id never fails the whole call.
 */
module.exports.bulkUpdateCaCheck = async (req, res) => {
    const decodedToken = jwt.decode(req.get('Authorization'));
    // Same rule as PATCH /request/:id: only CA may set ca_approved / ca_check.
    if (!decodedToken?.role || decodedToken.role !== 'CA') {
        return res.status(STATUS.UNAUTHORISED).json({ message: 'Only CA role can set ca_check' });
    }

    const { ids, ca_check } = req.body || {};
    if (!['APPROVED', 'REJECTED'].includes(ca_check)) {
        return res.status(STATUS.BAD_REQUEST).json({
            message: 'ca_check must be APPROVED or REJECTED',
            field: 'ca_check',
        });
    }
    if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(STATUS.BAD_REQUEST).json({ message: 'ids must be a non-empty array', field: 'ids' });
    }
    if (ids.length > CA_BULK_MAX_IDS) {
        return res.status(STATUS.BAD_REQUEST).json({
            message: `Too many ids: max ${CA_BULK_MAX_IDS} per call`,
            field: 'ids',
            max: CA_BULK_MAX_IDS,
        });
    }

    const approved = ca_check === 'APPROVED';
    const updated = [];
    const failed = [];
    const seen = new Set();
    const toUpdate = [];
    for (const raw of ids) {
        const id = typeof raw === 'string' ? raw.trim() : String(raw ?? '');
        if (seen.has(id)) continue; // duplicate: processed once
        seen.add(id);
        if (!mongoose.Types.ObjectId.isValid(id) || String(new mongoose.Types.ObjectId(id)) !== id) {
            failed.push({ id, message: 'Invalid id' });
            continue;
        }
        toUpdate.push(id);
    }

    const updateOne = async (id) => {
        const now = new Date();
        const result = await Request.updateOne(
            { _id: id, ca_check: 'PENDING' },
            {
                $set: {
                    ca_check,
                    ca_approved: approved,
                    ca_approved_by: decodedToken.uid,
                    ca_approved_at: now,
                    status: ca_check,
                    handled_by: decodedToken.uid,
                },
            }
        ).maxTimeMS(15000);
        if (result.matchedCount === 1) {
            updated.push(id);
            return;
        }
        const current = await Request.findById(id).select('ca_check').lean();
        failed.push({
            id,
            message: current ? `Not pending (ca_check is ${current.ca_check || 'unset'})` : 'Not found',
        });
    };

    try {
        for (let i = 0; i < toUpdate.length; i += CA_BULK_CONCURRENCY) {
            const chunk = toUpdate.slice(i, i + CA_BULK_CONCURRENCY);
            await Promise.all(
                chunk.map((id) =>
                    updateOne(id).catch((error) => {
                        console.error('bulkUpdateCaCheck id', id, error);
                        failed.push({ id, message: 'Update failed' });
                    })
                )
            );
        }
        // Keep the response in the caller's order.
        const order = new Map(ids.map((raw, i) => [typeof raw === 'string' ? raw.trim() : String(raw ?? ''), i]));
        updated.sort((a, b) => order.get(a) - order.get(b));
        failed.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
        return res.status(STATUS.SUCCESS).json({ updated, failed });
    } catch (error) {
        console.error('bulkUpdateCaCheck:', error);
        return res.status(STATUS.INTERNAL_SERVER_ERROR).json({
            message: MESSAGE.internalServerError,
            error: error.message,
        });
    }
};
