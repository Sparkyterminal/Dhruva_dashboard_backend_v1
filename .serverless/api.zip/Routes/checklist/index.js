const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const isAuth = require('../../authentication/is-auth');
const checklistController = require('../../Controlers/checklist');

// Create checklist
router.post(
    "/",
    isAuth,
    [
        body('heading').trim().not().isEmpty().withMessage('Heading is required'),
        body('eventReference').optional().trim(),
        body('subHeadings').isArray({ min: 1 }).withMessage('SubHeadings must be a non-empty array'),
        body('subHeadings.*.subHeadingName').not().isEmpty().withMessage('Each subHeading must have a subHeadingName'),
        body('subHeadings.*.checklists').isArray({ min: 1 }).withMessage('Each subHeading must have a non-empty checklists array'),
        body('subHeadings.*.checklists.*.checklistName').not().isEmpty().withMessage('Each checklist must have a checklistName')
    ],
    checklistController.createChecklist
);

router.get(
    "/",
    isAuth,
    checklistController.getChecklists
);

// Get single checklist by ID
router.get(
    "/:id",
    isAuth,
    checklistController.getChecklistById
);

// Update checklist
router.patch(
    "/:id",
    isAuth,
    checklistController.updateChecklist
);

// Update checklist status
router.patch(
    "/status/:id",
    isAuth,
    [
        body('is_active').trim().not().isEmpty()
    ],
    checklistController.updateChecklistStatus
);

// Archive or activate checklist
router.patch(
    "/archive/:id",
    isAuth,
    checklistController.archiveOrActiveChecklist
);

// Delete checklist
router.delete(
    "/:id",
    isAuth,
    checklistController.deleteChecklist
);

// Get all active checklists
router.get(
    "/active/all",
    isAuth,
    checklistController.getAllActiveChecklists
);

module.exports = router;

